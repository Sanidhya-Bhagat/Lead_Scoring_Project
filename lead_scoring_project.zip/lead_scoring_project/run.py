from app.preprocess import load_data, clean_data
from app.scoring import score_lead

# Load and clean data
df = load_data("data/raw_data.xlsx")
df = clean_data(df)

scores = []
explanations = []

# Score each company
for _, row in df.iterrows():
    score, explanation = score_lead(row.to_dict())
    scores.append(score)
    explanations.append(", ".join(explanation))

# Add results to dataframe
df["score"] = scores
df["explanation"] = explanations

# Save output
df.to_csv("output_scored.csv", index=False)
df.to_excel("output_scored.xlsx", index=False)

print("✅ Scoring complete!")
print("📁 Files saved: output_scored.csv, output_scored.xlsx")