from fastapi import FastAPI
from app.scoring import score_lead

app = FastAPI()


@app.get("/")
def home():
    return {"message": "Lead Scoring API Running"}


@app.post("/score")
def get_score(data: dict):
    score, explanation = score_lead(data)

    return {
        "score": score,
        "explanation": explanation
    }