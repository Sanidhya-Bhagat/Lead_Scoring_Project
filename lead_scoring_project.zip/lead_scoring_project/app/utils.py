import re

#Data Validation
def convert_employees(emp_str):
    if not isinstance(emp_str, str):
        return 0

    emp_str = emp_str.replace(",", "").strip()

    if "+" in emp_str:
        return int(emp_str.replace("+", ""))

    if "-" in emp_str:
        parts = emp_str.split("-")
        nums = []
        for p in parts:
            p = p.strip()
            if p.isdigit():
                nums.append(int(p))

        return sum(nums) // len(nums) if nums else 0

    return 0

# Convert funding "$991M", "$1B" → number
def convert_funding(funding_str):
    if not isinstance(funding_str, str):
        return 0

    funding_str = funding_str.replace("$", "").strip()

#Safety-Net
    try:
        if "B" in funding_str:
            return float(funding_str.replace("B", "")) * 1_000_000_000
        elif "M" in funding_str:
            return float(funding_str.replace("M", "")) * 1_000_000
        elif "K" in funding_str:
            return float(funding_str.replace("K", "")) * 1_000
        else:
            return float(funding_str)
    except:
        return 0