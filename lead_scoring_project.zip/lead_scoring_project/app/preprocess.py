import pandas as pd
try:
    from app.utils import convert_employees, convert_funding
except:
    from utils import convert_employees, convert_funding


def load_data(path):
    df = pd.read_excel(path)
    return df


def clean_data(df):
    # Keep only useful columns
    df = df[[
        "Company name",
        "Company number of employees",
        "Company revenue",
        "Company main industry",
        "Seniority",
        "Total funding amount"
    ]]

    # Remove duplicates
    df = df.drop_duplicates()

    # Fill missing values
    df["Company revenue"] = df["Company revenue"].fillna("Unknown")
    df["Company number of employees"] = df["Company number of employees"].fillna("Unknown")
    df["Company main industry"] = df["Company main industry"].fillna("Unknown")
    df["Seniority"] = df["Seniority"].fillna("Unknown")
    df["Total funding amount"] = df["Total funding amount"].fillna(0)

    # Convert to numeric
    df["employees_numeric"] = df["Company number of employees"].apply(convert_employees)
    df["funding_numeric"] = df["Total funding amount"].apply(convert_funding)

    return df


if __name__ == "__main__":
    df = load_data("data/raw_data.xlsx")
    df = clean_data(df)

    print("\n--- FINAL CLEANED DATA ---")
    print(df[[
        "Company name",
        "Company number of employees",
        "employees_numeric",
        "Total funding amount",
        "funding_numeric"
    ]].head())

    print("\n--- MISSING VALUES ---")
    print(df.isnull().sum())