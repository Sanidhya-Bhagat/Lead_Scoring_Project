def score_lead(data):
    score = 0
    explanation = []

    # Company Size (numeric)
    employees = data.get("employees_numeric", 0)

    if employees > 5000:
        score += 25
        explanation.append("Large company")
    elif employees > 500:
        score += 15
        explanation.append("Medium company")
    else:
        score += 5
        explanation.append("Small company")

    # Funding
    funding = data.get("funding_numeric", 0)

    if funding > 500_000_000:
        score += 20
        explanation.append("Highly funded")
    elif funding > 50_000_000:
        score += 10
        explanation.append("Moderately funded")

    # Seniority
    seniority = str(data.get("Seniority", "")).lower()

    if "ceo" in seniority or "founder" in seniority:
        score += 20
        explanation.append("Decision maker")
    elif "vp" in seniority or "vice president" in seniority:
        score += 15
        explanation.append("Senior leadership")
    elif "manager" in seniority:
        score += 10
        explanation.append("Mid-level")

    # Industry
    industry = str(data.get("Company main industry", "")).lower()

    if "software" in industry or "technology" in industry or "ai" in industry:
        score += 20
        explanation.append("High-fit industry")

    return min(score, 100), explanation